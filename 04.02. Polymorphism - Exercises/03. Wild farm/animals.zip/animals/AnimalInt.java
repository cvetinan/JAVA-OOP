package wildfarm.animals;

import wildfarm.food.Food;

public interface AnimalInt {
    void makeSound();
    void eat(Food food);
}
