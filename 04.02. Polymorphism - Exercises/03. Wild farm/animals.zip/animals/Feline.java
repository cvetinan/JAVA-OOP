package wildfarm.animals;

public abstract class Feline extends Mammal {
    protected Feline(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
