public interface Vehicle {
    void drive();

    void refuel();
}
