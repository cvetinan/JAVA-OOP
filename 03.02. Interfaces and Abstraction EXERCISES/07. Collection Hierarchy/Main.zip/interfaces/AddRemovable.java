package interfaces;

public interface AddRemovable extends Addable {
    String remove();
}
