package interfaces;

public interface Addable {
    int add(String string);
}
