package military.enumaration;


public enum State {
    inProgress,
    Finished,
}
