package military.enumaration;

public enum Corp {
    Airforces,
    Marines,
}
