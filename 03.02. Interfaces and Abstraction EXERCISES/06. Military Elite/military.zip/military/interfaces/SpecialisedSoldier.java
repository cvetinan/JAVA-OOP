package military.interfaces;


public interface SpecialisedSoldier extends Private{
    String getCorps();
}
