package military.interfaces;

public interface Spy extends Soldier{
    Integer getCodeNumber();
}
